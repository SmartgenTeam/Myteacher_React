import React, { Component } from 'react'
import { View, Text, StyleSheet, Image, TouchableOpacity, StatusBar, FlatList, ActivityIndicator } from 'react-native'
import COLORS from '../styles/color';
import { STRING, url } from '../values/string';
import AsyncStorage from '@react-native-community/async-storage';
import FooterLayout from './FooterLayout';
import { ScrollView } from 'react-native-gesture-handler';
import { DrawerActions } from "react-navigation-drawer";
import GLOBALSTYLE from '../values/style';
import DBMigrationHelper from '../dbhelper/DBMigrationHelper';
import MESSAGE from '../values/message';
import { getMessage, getValue } from '../util/Util';
import LABEL from '../values/label';

var db, topicThumbBaseURL;

class TopicDetailActivity extends Component {

    constructor(props) {

        db = DBMigrationHelper.getInstance();
        super(props);
        this.state = {
            topicid: '',
            topicName: '',
            topicdetail: this.props.navigation.getParam("topicdetail", ''),
            chapterItem: this.props.navigation.getParam("chapters", ''),
            isLoading: false,
            langId: '',
        };
    }

    componentDidMount() {
        this.setStates();
    }

    async setStates() {
        topicThumbBaseURL = await url(STRING.topicThumbBaseURL);

        this.setState({
            topicName: await AsyncStorage.getItem(STRING.TOPICNAME),
            langId: await AsyncStorage.getItem(STRING.LANGUAGEID),
        })
    }

    async openDetail(item, index) {
        await AsyncStorage.setItem(STRING.TOPICID, item.topics[index].topicId);
        await AsyncStorage.setItem(STRING.TOPICNAME, item.topics[index].topicName);
        await AsyncStorage.setItem(STRING.VIDEOURL, item.topics[index].videoUrl + "");

        db.isMataDataExist(item.topics[index].topicId, item.topics[index].topicName);

        // db.isTopicViwed(isTopicVisited => {
        //     if (isTopicVisited) {
        //         this.props.navigation.navigate('topicDetailActivity', { 'topicdetail': item.topics[index] })
        //     } else {
        //         this.props.navigation.navigate('quizActivity', { 'isPreAssessment': true, 'isFromDetailActivity': false })
        //     }
        // }, item.topics[index].topicId);
        this.props.navigation.replace('topicDetailActivity', { 'topicdetail': item.topics[index], 'chapters': this.state.chapterItem })
    }

    buttonPressed = () => {
        this.props.navigation.goBack(null)
    };

    render() {
        return (
            <View style={{ backgroundColor: COLORS.green, height: '100%', width: '100%' }}>
                <StatusBar hidden={true} />
                <Image
                    style={{ width: '100%', height: '100%' }}
                    source={require('../images/img_page_bg.png')}
                />
                <TouchableOpacity style={{ justifyContent: 'center', flex: 0.33, position: 'absolute', padding: 12 }}
                    onPress={() => this.props.navigation.goBack(null)}>
                    <Image
                        style={{ height: 25, width: 25, alignSelf: 'flex-start' }}
                        source={require('../images/ic_back_blue.png')} />
                </TouchableOpacity>

                <View style={{ width: '100%', height: '90%', position: 'absolute', marginTop: 45 }}>
                    <View style={{ width: '100%', height: 250 }}>
                        <Image style={{ width: '100%', height: "100%" }}
                            source={{ uri: 'https://my-teacher-aal.s3.ap-south-1.amazonaws.com/images/' + this.state.topicdetail.thumbPath }} />
                        <Text style={{ color: COLORS.white, width: '100%', textAlign: 'center', textAlignVertical: 'center', height: 40, backgroundColor: 'rgba(10,55,0,0.5)', position: 'absolute', paddingLeft: 8, paddingRight: 8, bottom: 0 }} numberOfLines={2} ellipsizeMode='tail'>{this.state.topicName}</Text>
                    </View>
                    <ScrollView style={{ marginTop: 15, marginBottom: 20 }}>
                        <View style={{ width: '90%', elevation: 8, backgroundColor: COLORS.white, borderRadius: 8, alignSelf: "center", margin: 10 }}>
                            {/* <Text style={{ alignSelf: 'center', paddingTop: 8, paddingBottom: 8, color: COLORS.blue }}>{getValue(LABEL.teacherResource, this.state.langId)}</Text> */}
                            <View style={{ width: '100%', height: 45, marginBottom: 8, marginTop: 8, flexDirection: 'row', alignSelf: "center" }} numCoumnls={2}>
                                {this.state.topicdetail.isPreAssessment
                                    ?
                                    <TouchableOpacity style={{ justifyContent: 'center', flex: 0.25 }} onPress={() => this.props.navigation.navigate('quizActivity', { 'isPreAssessment': true, 'isFromDetailActivity': true })}>
                                        <Image
                                            style={{ height: 25, width: 25, alignSelf: 'center' }}
                                            source={require('../images/ic_quiz.png')} />
                                        <Text style={{ alignSelf: 'center', paddingTop: 4, color: COLORS.blue, fontSize: 10 }}>{getValue(LABEL.preTest, this.state.langId)}</Text>
                                    </TouchableOpacity>
                                    :
                                    <View style={{ flex: 0.25 }}></View>
                                }
                                {this.state.topicdetail.isNote
                                    ?
                                    <TouchableOpacity style={{ justifyContent: 'center', flex: 0.25 }} onPress={() => this.props.navigation.navigate('notesActivity', { 'isFromDetailActivity': true })}>
                                        <Image
                                            style={{ height: 25, width: 20, alignSelf: 'center' }}
                                            source={require('../images/ic_notes.png')} />
                                        <Text style={{ alignSelf: 'center', paddingTop: 4, color: COLORS.blue, fontSize: 10 }}>{getValue(LABEL.notes, this.state.langId)}</Text>
                                    </TouchableOpacity>
                                    :
                                    <View style={{ flex: 0.25 }}></View>
                                }
                                {this.state.topicdetail.isVideo
                                    ?
                                    <TouchableOpacity style={{ justifyContent: 'center', flex: 0.25 }} onPress={() => this.props.navigation.navigate('videoActivity', { 'isFromDetailActivity': true })}>
                                        <Image
                                            style={{ height: 25, width: 25, alignSelf: 'center' }}
                                            source={require('../images/ic_video.png')} />
                                        <Text style={{ alignSelf: 'center', paddingTop: 4, color: COLORS.blue, fontSize: 10 }}>{getValue(LABEL.video, this.state.langId)}</Text>
                                    </TouchableOpacity>
                                    :
                                    <View style={{ flex: 0.25 }}></View>
                                }
                                {this.state.topicdetail.isPostAssessment
                                    ?
                                    <TouchableOpacity style={{ justifyContent: 'center', flex: 0.25 }} onPress={() => this.props.navigation.navigate('quizActivity', { 'isPreAssessment': false, 'isFromDetailActivity': true })}>
                                        <Image
                                            style={{ height: 25, width: 25, alignSelf: 'center' }}
                                            source={require('../images/ic_quiz.png')} />
                                        <Text style={{ alignSelf: 'center', paddingTop: 4, color: COLORS.blue, fontSize: 10 }}>{getValue(LABEL.postTest, this.state.langId)}</Text>
                                    </TouchableOpacity>
                                    :
                                    <View style={{ flex: 0.25 }}></View>
                                }
                            </View>
                        </View>
                        {/* <View style={{ marginTop: 15, marginBottom: 15, width: '90%', elevation: 8, backgroundColor: COLORS.white, borderRadius: 8, alignSelf: "center" }}>
                            <Text style={{ alignSelf: 'center', paddingTop: 8, paddingBottom: 8, color: COLORS.blue }}>Teacher Resource</Text>
                            <View style={{ width: '100%', height: 45, marginBottom: 8, flexDirection: 'row', alignSelf: "center" }} numCoumnls={2}>
                                <TouchableOpacity style={{ justifyContent: 'center', flex: 0.25 }} onPress={() => this.props.navigation.navigate('')}>
                                    <Image
                                        style={{ height: 25, width: 20, alignSelf: 'center' }}
                                        source={require('../images/ic_document.png')} />
                                </TouchableOpacity>
                                <TouchableOpacity style={{ justifyContent: 'center', flex: 0.25 }} onPress={() => this.props.navigation.navigate('')}>
                                    <Image
                                        style={{ height: 25, width: 20, alignSelf: 'center' }}
                                        source={require('../images/ic_weblink.png')} />
                                </TouchableOpacity>
                                <TouchableOpacity style={{ justifyContent: 'center', flex: 0.25 }} onPress={() => this.props.navigation.navigate('')}>
                                    <Image
                                        style={{ height: 25, width: 25, alignSelf: 'center' }}
                                        source={require('../images/ic_youtube.png')} />
                                </TouchableOpacity>
                                <TouchableOpacity style={{ justifyContent: 'center', flex: 0.25 }} onPress={() => this.props.navigation.navigate('')}>
                                    <Image
                                        style={{ height: 25, width: 25, alignSelf: 'center' }}
                                        source={require('../images/ic_video.png')} />
                                </TouchableOpacity>
                                <TouchableOpacity style={{ justifyContent: 'center', flex: 0.25 }} onPress={() => this.props.navigation.navigate('')}>
                                    <Image
                                        style={{ height: 25, width: 25, alignSelf: 'center' }}
                                        source={require('../images/ic_quiz.png')} />
                                </TouchableOpacity>
                            </View>
                        </View> */}

                        <Text style={{ padding: 10, color: COLORS.blue, }}>{getValue(LABEL.recommendedTopics, this.state.langId)}</Text>
                        {this.state.chapterItem.topics.length > 0 ?
                            <FlatList
                                data={this.state.chapterItem.topics}
                                renderItem={({ item, index }) => (
                                    this.state.topicdetail.topicId != item.topicId ?
                                        <View style={{ paddingEnd: 10 }}>
                                            <TouchableOpacity
                                                activeOpacity={0.6}
                                                style={GLOBALSTYLE.imageThumbnailList}
                                                // onPress={() => this.props.navigation.navigate('topicDetailActivity', { 'topicId': item.topicId, 'topicName': item.topicName, 'topicData': item })}>
                                                onPress={() => this.openDetail(this.state.chapterItem, index)}>
                                                {
                                                    <Image
                                                        style={{ height: '100%', width: '100%', borderRadius: 14 }}
                                                        source={{ uri: topicThumbBaseURL + item.thumbPath }} />}
                                                <Text style={GLOBALSTYLE.thumbnailTitle} numberOfLines={2} ellipsizeMode='tail'>{item.topicName}</Text>
                                            </TouchableOpacity>
                                        </View>
                                        :
                                        <View></View>
                                )}
                                //Setting the number of column
                                horizontal={true}
                                keyExtractor={(item, index) => index.toString()}
                            />
                            :
                            <Text style={{ paddingTop: 15, paddingBottom: 5, textAlign: 'center', fontSize: 16, color: COLORS.darkGrey }} >{getMessage(MESSAGE.noTopic, this.state.langId)}</Text>
                        }
                    </ScrollView>
                </View>

                <FooterLayout
                    onPressDrawer={this.toggleDrawer}
                    onPressHome={this.goToHome}
                    onPressNotification={this.goToNotification} />
            </View >
        )
    }

    toggleDrawer = () => {
        this.props.navigation.dispatch(DrawerActions.openDrawer());
    }

    goToHome = () => {
        this.props.navigation.navigate('dashBoardActivity')
    }

    goToNotification = () => {
        this.props.navigation.navigate('notificationActivity')
    }
}

export default TopicDetailActivity

const styles = StyleSheet.create({
    container: {
        width: '90%',
        height: '75%',
        padding: 5,
        margin: 5,
        backgroundColor: COLORS.offWhite,
        borderRadius: 8,
        shadowOpacity: 0,
        elevation: 5,
        alignSelf: "center"
    },
    input: {
        padding: 8,
        height: 45,
        marginTop: 30,
        borderWidth: 0.01,
        borderRadius: 4,
        elevation: 2
    },
    submitButton: {
        backgroundColor: COLORS.pink,
        padding: 10,
        height: 40,
        marginTop: 30,
        borderRadius: 4,
        elevation: 3
    },
    submitButtonText: {
        color: COLORS.white,
        textAlign: 'center'
    },
})