import React, { Component } from 'react'
import { View, Text, StyleSheet, Image, TouchableOpacity, StatusBar } from 'react-native'
import COLORS from '../styles/color';
import { STRING, url } from '../values/string';
import GLOBALSTYLE from '../values/style';
import Video from 'react-native-video';
import AsyncStorage from '@react-native-community/async-storage';
import KeepAwake from 'react-native-keep-awake';

var videoURL, videoBaseURL;

import { NativeModules } from 'react-native';
import LABEL from '../values/label';
import { getValue } from '../util/Util';
var ServiceModule = NativeModules.ServiceModule;

class VideoActivity extends Component {

    constructor(props) {
        super(props);

        this.state = {
            isLoading: false,
            isFromDetailActivity: this.props.navigation.getParam("isFromDetailActivity", true),
            languageId: '',
            topicId: '',
            topicName: '',
            videoURL: 'http://www.dummyurl.com/dummy.mp4',
            fileName: '',
            isNoteAvailable: false,
            langId: '',
        }
    }

    componentDidMount() {
        KeepAwake.activate();
        this.setStates();
    }

    async setStates() {
        videoBaseURL = await url(STRING.videoBaseURL);

        this.setState({
            topicId: await AsyncStorage.getItem(STRING.TOPICID),
            topicName: await AsyncStorage.getItem(STRING.TOPICNAME),
            languageId: await AsyncStorage.getItem(STRING.LANGUAGEID),
            fileName: await AsyncStorage.getItem(STRING.VIDEOURL),
            langId: await AsyncStorage.getItem(STRING.LANGUAGEID),
        })

        
        // ServiceModule.getDynamicPort((err) => {
        // }, (PORT) => {
        //     videoURL = STRING.servieBaseURL + PORT + "/" + videoBaseURL + this.state.fileName;
            
        //     this.setState({
        //         videoURL: videoURL,
        //     })
        // });
        this.setState({
            videoURL: videoBaseURL + this.state.fileName,
        }, () => {
            console.log(this.state.videoURL);
        });
    }

    render() {
        return (
            <View style={{ backgroundColor: COLORS.green, height: '100%', width: '100%' }}>
                <StatusBar hidden={true} />
                <Image
                    style={{ width: '100%', height: '100%' }}
                    source={require('../images/img_page_bg.png')}
                />
                {/* <Image
                    style={{ width: 150, height: 150, alignSelf: "flex-end", position: 'absolute', }}
                    source={require('../images/img_bg_wc.png')}
                /> */}
                <TouchableOpacity style={{ justifyContent: 'center', flex: 0.33, position: 'absolute', padding:12 }}
                    onPress={() => this.props.navigation.goBack(null)}>
                    <Image
                        style={{ height: 25, width: 25, alignSelf: 'flex-start' }}
                        source={require('../images/ic_back_blue.png')} />
                </TouchableOpacity>
                <View style={{ opacity: 1, backgroundColor: 'rgba(192,192,192, 0.75)', height: '90%', width: '100%', position: 'absolute', marginTop: 50 }}>
                    <Video source={{ 
                        uri: this.state.videoURL,
                        headers: {
                            'Referer': 'http://3.7.171.194/'
                        }
                     }}   // Can be a URL or a local file.

                        ref={(ref) => {
                            this.player = ref
                        }}                                      // Store reference
                        onBuffer={this.onBuffer}                // Callback when remote video is buffering
                        onError={this.videoError}               // Callback when video cannot be loaded
                        style={styles.backgroundVideo}
                        controls={true} />
                </View>


                <View style={{ width: '100%', position: 'absolute', bottom: 0, backgroundColor: COLORS.white, borderTopStartRadius: 25, borderTopEndRadius: 25, borderColor: COLORS.darkGrey, borderWidth: 0.5 }}>
                    <TouchableOpacity
                        onPress={() => { this.state.isFromDetailActivity ? this.props.navigation.goBack(null) : this.props.navigation.replace('quizActivity', { 'isPreAssessment': false }) }}
                        style={{ textAlign: 'center', bottom: 0, padding: 10, color: COLORS.blue, fontWeight: 'bold' }}>
                        <Text style={GLOBALSTYLE.nextPrevBtn}>{this.state.isFromDetailActivity ? getValue(LABEL.close, this.state.langId) : getValue(LABEL.next, this.state.langId)}</Text>
                    </TouchableOpacity>
                </View>
            </View >
        )
    }
}

export default VideoActivity

var styles = StyleSheet.create({
    backgroundVideo: {
        position: 'absolute',
        top: 0,
        left: 0,
        bottom: 25,
        right: 0,
    },
});